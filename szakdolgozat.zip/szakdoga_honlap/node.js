var express = require('express'); //query parameter
const request = require('request');
var app = express();
var path = require('path');

var parseString = require('xml2js').parseString; //parseString import

var today = new Date();
var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

// viewed at http://localhost:3000
app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/static/exchange_rate_comparison.html'));
});

app.get('/otp', (req, res) => {
    request('http://www.otpbank.hu/apps/exchangerate/api/exchangerate/otp/'+date, { json: true }, (err, response, body) => {   //${new Date().toISOString().split('T')[0]}
        if (err) { return console.log(err); }
        res.send(body);
    });
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/static/exchange_rate_comparison.html'));
});

app.get('/bank', (req, res) => {
    request(`http://api.napiarfolyam.hu/?bank=${req.query.bank}&valuta=${req.query.valuta}`, { xml: true }, (err, response, body) => {
        if (err) { return console.log(err); }
        parseString(body, function (err, result) {
            res.send(result);
        });

    });
});

app.use(express.static('static'))

app.listen(3000);