async function otp_api_call() { //OTP

    var bank_name = document.getElementById("banks").value;
  
    var base_currency = document.getElementById("from_currency").value;
    var target_currency = document.getElementById("to_currency").value;
  
    var amount = document.getElementById("amount").value;
  
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
  
    let result = await fetch('http://localhost:3000/otp', {mode: 'no-cors'})
      .then(response => {
        return response.json();
      })
      .then(data => {
        let versions = data['dates'][0]['versions'];
        return versions[versions.length - 1];
      });
  
    console.log(result['exchangeRates'].find(element => element['currencyCode'] == base_currency));
    var valami=result['exchangeRates'].find(element => element['currencyCode']==base_currency);
    document.getElementById("otp_result").innerHTML = valami['currencySellingRate'];

  }