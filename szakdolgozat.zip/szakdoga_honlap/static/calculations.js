async function calculations() {

    var endpoint = 'latest';
    var access_key = 'efe76139305494bc8ec94d80ef33c01b';

    var bank_name = document.getElementById("banks").value;
    var bank_id = document.getElementById("banks");
    var neo_bank_name = document.getElementById("neobank").value;
    var neobank_id = document.getElementById("neobank");
    var neobank_teljes_name = neobank_id.options[neobank_id.selectedIndex].text;


    var base_currency = document.getElementById("from_currency").value;
    var base_currency_id = document.getElementById("from_currency");
    var target_currency = document.getElementById("to_currency").value;
    var target_currency_id = document.getElementById("to_currency");

    var base_currency_teljes_name = base_currency_id.options[base_currency_id.selectedIndex].text;
    var target_currency_teljes_name = target_currency_id.options[target_currency_id.selectedIndex].text;
    var bank_teljes_name = bank_id.options[bank_id.selectedIndex].text;

    var amount = document.getElementById("amount").value;

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

    var base_url = 'http://api.napiarfolyam.hu/';
    var url = 'http://api.napiarfolyam.hu/?bank=kh&valuta=eur';

    $.ajax({
        url: 'http://data.fixer.io/api/' + endpoint + '?access_key=' + access_key,
        dataType: 'jsonp',
        success: function (json) {
            var base_currency_rate = json.rates[base_currency];
            var target_currency_rate = json.rates[target_currency];
            var neo_converted = convert_function(base_currency_rate, target_currency_rate, amount);

            if (neo_bank_name == "Revolut") { //https://www.revolut.com/help/getting-started/exchanging-currencies/what-foreign-exchange-rate-will-i-get
                if (today.getDay() == 0 || today.getDay() == 6) {
                    if (target_currency == "THB" || target_currency == "UAH") {
                        var twoprcnt_fee_included = neo_converted - (neo_converted * 0.02); //prcnt=% (percent)
                        neo_converted = twoprcnt_fee_included;
                    } else {
                        var halfprcnt_fee_included = neo_converted - (neo_converted * 0.005);
                        neo_converted = halfprcnt_fee_included;
                    }
                }
                else {
                    if (target_currency == "THB" || target_currency == "UAH") {
                        var oneprcnt_fee_included = neo_converted - (neo_converted * 0.01);
                        neo_converted = oneprcnt_fee_included;
                    } else if ((target_currency != "THB" || target_currency != "UAH") && convert_function(base_currency_rate, json.rates.GBP, amount) > 5000) {
                        var halfprcnt_fee_included = neo_converted - (neo_converted * 0.005);
                        neo_converted = halfprcnt_fee_included;
                    }
                }
            }

            document.getElementById("neo_exchange").innerHTML = neo_converted;
            document.getElementById("neo_exchange").innerHTML = `${amount} ${base_currency_teljes_name}-ért a(z) ${neobank_teljes_name} ${neo_converted} 
        ${target_currency_teljes_name}-t ad.`;
        }
    })

    let result = await fetch('http://localhost:3000/otp', { mode: 'no-cors' })
        .then(response => {
            return response.json();
        })
        .then(data => {
            let versions = data['dates'][0]['versions'];
            return versions[versions.length - 1];
        });

    console.log(result['exchangeRates'].find(element => element['currencyCode'] == base_currency));
    var valami = result['exchangeRates'].find(element => element['currencyCode'] == base_currency);
    document.getElementById("otp_result").innerHTML = valami['currencySellingRate'];

    let fetch_base_currency = await fetch('http://localhost:3000/bank/?bank=' + bank_name + '&valuta=' + base_currency, { mode: 'no-cors' })
        .then(response => {
            return response.text();
        })

    let fetch_target_currency = await fetch('http://localhost:3000/bank/?bank=' + bank_name + '&valuta=' + target_currency, { mode: 'no-cors' })
        .then(response => {
            return response.text();
        })

    var base_currency_rate = JSON.parse(fetch_base_currency)['arfolyamok']['valuta'][0]['item'][0]['vetel'][0];
    console.log(base_currency_rate);
    var target_currency_rate = JSON.parse(fetch_target_currency)['arfolyamok']['valuta'][0]['item'][0]['eladas'][0];
    console.log(target_currency_rate);

    //var convert = (base_currency_rate / target_currency_rate) * amount;
    var convert = amount * base_currency_rate / target_currency_rate;
    console.log(convert);

    document.getElementById("bank_exchange").innerHTML = `${amount} ${base_currency_teljes_name}-ért a(z) ${bank_teljes_name} ${convert} 
  ${target_currency_teljes_name}-t ad.`;

}

function convert_function(base_currency_rate, target_currency_rate, amount) {
    var convert = (target_currency_rate / base_currency_rate) * amount;
    return convert;
}