import {convert} from './bank_api.js'

function calculations(){

    
alert(convert);

}