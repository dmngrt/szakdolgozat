async function bank_api_call() {

  var bank_name = document.getElementById("banks").value;
  var bank_id=document.getElementById("banks");

  var bank_teljes_name = bank_id.options[bank_id.selectedIndex].text;

  var base_currency = document.getElementById("from_currency").value;
  var base_currency_id=document.getElementById("from_currency");
  var target_currency = document.getElementById("to_currency").value;
  var target_currency_id=document.getElementById("to_currency");

  var base_currency_teljes_name = base_currency_id.options[base_currency_id.selectedIndex].text;
  var target_currency_teljes_name = target_currency_id.options[target_currency_id.selectedIndex].text;

  var amount = document.getElementById("amount").value;

  var base_url = 'http://api.napiarfolyam.hu/';
  var url = 'http://api.napiarfolyam.hu/?bank=kh&valuta=eur';

  var today = new Date();

  let fetch_base_currency = await fetch('http://localhost:3000/bank/?bank=' + bank_name + '&valuta=' + base_currency, { mode: 'no-cors' })
    .then(response => {
      return response.text();
    })

  let fetch_target_currency = await fetch('http://localhost:3000/bank/?bank=' + bank_name + '&valuta=' + target_currency, { mode: 'no-cors' })
    .then(response => {
      return response.text();
    })

  var base_currency_rate = JSON.parse(fetch_base_currency)['arfolyamok']['valuta'][0]['item'][0]['vetel'][0];
  console.log(base_currency_rate);
  var target_currency_rate = JSON.parse(fetch_target_currency)['arfolyamok']['valuta'][0]['item'][0]['eladas'][0];
  console.log(target_currency_rate);

  //var convert = (base_currency_rate / target_currency_rate) * amount;
  var convert = amount*base_currency_rate/target_currency_rate;
  console.log(convert);

  document.getElementById("bank_exchange").innerHTML=`${amount} ${base_currency_teljes_name}-ért a(z) ${bank_teljes_name} ${convert} 
  ${target_currency_teljes_name}-t ad.`;

  export {convert};
  //document.getElementById("otp_result").innerHTML = exchange_rate2;
}