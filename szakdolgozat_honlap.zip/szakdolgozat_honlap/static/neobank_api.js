function neobank_api_call() {

  var endpoint = 'latest';
  var access_key = 'efe76139305494bc8ec94d80ef33c01b';


  var neo_bank_name = document.getElementById("neobank").value;
  var neobank_id = document.getElementById("neobank");
  var neobank_teljes_name = neobank_id.options[neobank_id.selectedIndex].text;


  var base_currency = document.getElementById("from_currency").value;
  var base_currency_id = document.getElementById("from_currency");
  var target_currency = document.getElementById("to_currency").value;
  var target_currency_id = document.getElementById("to_currency");

  var base_currency_teljes_name = base_currency_id.options[base_currency_id.selectedIndex].text;
  var target_currency_teljes_name = target_currency_id.options[target_currency_id.selectedIndex].text;

  var amount = document.getElementById("amount").value;

  var today = new Date();

  $.ajax({
    url: 'http://data.fixer.io/api/' + endpoint + '?access_key=' + access_key,
    dataType: 'jsonp',
    success: function (json) {
      var base_currency_rate = json.rates[base_currency];
      var target_currency_rate = json.rates[target_currency];
      var neo_converted = convert(base_currency_rate, target_currency_rate, amount);

      if (neo_bank_name == "Revolut") { //https://www.revolut.com/help/getting-started/exchanging-currencies/what-foreign-exchange-rate-will-i-get
        if (today.getDay() == 0 || today.getDay() == 6) {
          if (target_currency == "THB" || target_currency == "UAH") {
            var twoprcnt_fee_included = neo_converted - (neo_converted * 0.02); //prcnt=% (percent)
            neo_converted = twoprcnt_fee_included;
          } else {
            var halfprcnt_fee_included = neo_converted - (neo_converted * 0.005);
            neo_converted = halfprcnt_fee_included;
          }
        }
        else {
          if (target_currency == "THB" || target_currency == "UAH") {
            var oneprcnt_fee_included = neo_converted - (neo_converted * 0.01);
            neo_converted = oneprcnt_fee_included;
          } else if ((target_currency != "THB" || target_currency != "UAH") && convert(base_currency_rate, json.rates.GBP, amount) > 5000) {
            var halfprcnt_fee_included = neo_converted - (neo_converted * 0.005);
            neo_converted = halfprcnt_fee_included;
          }
        }
      }

      document.getElementById("neo_exchange").innerHTML = neo_converted;
      document.getElementById("neo_exchange").innerHTML = `${amount} ${base_currency_teljes_name}-ért a(z) ${neobank_teljes_name} ${neo_converted} 
      ${target_currency_teljes_name}-t ad.`;
    }
  })
}

function convert(base_currency_rate, target_currency_rate, amount) {
  var convert = (target_currency_rate / base_currency_rate) * amount;
  return convert;
}